# GitHub Copilot Instructions

Project: testtesttesttest
Owner: pearcestephens

Connected to Intelligence Hub MCP Server
