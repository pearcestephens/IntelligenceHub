# 🎬 AUDIT GALLERY SYSTEM - COMPLETE REFERENCE

## 📋 System Overview

**Complete audit management system with web gallery for frontend testing**

### What It Does:
- ✅ Captures screenshots and videos during testing
- ✅ Uploads to GPT server (gpt.ecigdis.co.nz)
- ✅ Generates **direct image links** for bot responses
- ✅ Creates **gallery viewer** for audit history
- ✅ Logs all errors and audit activities
- ✅ Organizes by project/server ID
- ✅ Searchable web interface

---

## 🔗 URLs

### Gallery Viewer:
```
https://gpt.ecigdis.co.nz/audits/gallery.php
```

### Upload Endpoint:
```
https://gpt.ecigdis.co.nz/audits/upload.php
```

### Direct File Access:
```
https://gpt.ecigdis.co.nz/audits/files/{project_id}/{server_id}/{filename}
```

---

## 🤖 Bot Usage Example

### Simple Audit:
```javascript
const ComprehensiveAuditor = require('./examples/comprehensive-audit');

const auditor = new ComprehensiveAuditor({
  projectId: 'cis-frontend',
  serverId: 'staff-portal'
});

await auditor.initialize();
const result = await auditor.auditPage('https://staff.vapeshed.co.nz');

// Bot receives:
console.log(result.upload.directLink);   // Direct image URL
console.log(result.upload.galleryLink);  // Gallery viewer URL
```

### Bot Response Format:
```
✅ **PAGE AUDIT COMPLETE**

📍 **URL:** https://staff.vapeshed.co.nz
⏱️ **Duration:** 811ms

🔍 **ERROR SCAN RESULTS:**
   • Status: **CLEAN**
   • Total Errors: **0**

📸 **SCREENSHOT:**

🔗 **Direct Image Link:**
https://gpt.ecigdis.co.nz/audits/files/cis-frontend/staff-portal/audit_1762248424850.png

🖼️ **View in Gallery:**
https://gpt.ecigdis.co.nz/audits/gallery.php?project=cis-frontend&audit=1762248424850

📊 **Audit Details:**
   • Audit ID: audit_1762248424850_b14a43af
   • Project: cis-frontend
   • Server: staff-portal
   • File Size: 26KB
   • Timestamp: 2025-11-04T09:27:04.850Z
```

---

## 📁 Storage Structure

### On GPT Server:
```
/mcp/audits/
├── upload.php              # Upload handler
├── gallery.php             # Web gallery viewer
├── audits.db               # SQLite database (metadata)
└── files/                  # Organized file storage
    ├── {project_id}/
    │   ├── {server_id}/
    │   │   ├── audit_123_abc.png
    │   │   ├── audit_456_def.png
    │   │   └── audit_789_ghi.mp4
```

### On Frontend Tools:
```
/tmp/frontend-audits/
├── screenshots/
├── videos/
├── reports/
└── logs/
    ├── audits.log         # All audit activities
    └── errors.log         # All errors encountered
```

---

## 🛠️ Module Reference

### 1. Reporter (lib/reporter.js)
**Purpose:** Upload files and generate links

```javascript
const Reporter = require('./lib/reporter');

const reporter = new Reporter({
  projectId: 'cis-frontend',
  serverId: 'staff-portal',
  uploadUrl: 'https://gpt.ecigdis.co.nz/audits/upload.php',
  galleryUrl: 'https://gpt.ecigdis.co.nz/audits/gallery.php'
});

// Upload screenshot
const result = await reporter.uploadScreenshot('/tmp/test.png', {
  type: 'error-detection',
  page: 'login',
  errors: 5
});

console.log(result.directLink);    // https://gpt.ecigdis.co.nz/audits/files/...
console.log(result.galleryLink);   // https://gpt.ecigdis.co.nz/audits/gallery.php?...

// Format bot response
const botResponse = reporter.formatBotResponse(result, {
  errors: 5,
  page: 'login'
});
```

### 2. BrowserController (core/browser-controller.js)
**Purpose:** Browser automation

```javascript
const BrowserController = require('./core/browser-controller');

const browser = new BrowserController({ headless: true });
await browser.launch();
await browser.goto('https://staff.vapeshed.co.nz');
const title = await browser.getTitle();
const screenshot = await browser.screenshot();
await browser.close();
```

### 3. ErrorDetector (core/error-detector.js)
**Purpose:** Find PHP/JS errors

```javascript
const ErrorDetector = require('./core/error-detector');

const detector = new ErrorDetector(browser);
const result = await detector.scan();

console.log(result.summary.total);      // Total errors
console.log(result.summary.status);     // CLEAN/LOW/MEDIUM/HIGH/CRITICAL
console.log(result.errors.php);         // PHP errors array
console.log(result.errors.javascript);  // JS errors array
```

### 4. ScreenshotTool (core/screenshot-tool.js)
**Purpose:** Advanced screenshots

```javascript
const ScreenshotTool = require('./core/screenshot-tool');

const screenshotter = new ScreenshotTool(browser);

// Full page
await screenshotter.captureFullPage('/tmp/full.png');

// Responsive (mobile/tablet/desktop)
await screenshotter.captureResponsive('/tmp/responsive/', ['mobile', 'tablet', 'desktop']);

// Thumbnail
await screenshotter.captureThumbnail('/tmp/thumb.jpg', 320);
```

---

## 🎯 Gallery Features

### Web Interface:
- ✅ **Filter by:**
  - Project ID
  - Server ID
  - Type (screenshot/video/report)
  - Date range

- ✅ **View:**
  - Thumbnail grid
  - Full image preview
  - Video playback
  - Audit metadata
  - Error counts
  - File sizes
  - Timestamps

- ✅ **Actions:**
  - View full size
  - Download
  - Direct link copy
  - Pagination (50 per page)

### Database Schema (SQLite):
```sql
CREATE TABLE audits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    audit_id TEXT UNIQUE NOT NULL,
    project_id TEXT NOT NULL,
    server_id TEXT NOT NULL,
    filename TEXT NOT NULL,
    file_path TEXT NOT NULL,
    file_size INTEGER NOT NULL,
    file_type TEXT,
    metadata TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

---

## 📊 Logging System

### Audit Log (audits.log):
```json
{
  "timestamp": "2025-11-04T09:27:04.850Z",
  "auditId": "audit_1762248424850_b14a43af",
  "type": "screenshot",
  "result": {...},
  "metadata": {...}
}
```

### Error Log (errors.log):
```json
{
  "timestamp": "2025-11-04T09:27:04.850Z",
  "projectId": "cis-frontend",
  "serverId": "staff-portal",
  "type": "upload_failed",
  "error": "Connection timeout",
  "filePath": "/tmp/test.png"
}
```

---

## 🔐 Security

### API Authentication:
- API Key required: `31ce0106609a6c5bc4f7ece0deb2f764df90a06167bda83468883516302a6a35`
- CORS enabled for frontend tools
- File size limit: 100MB
- Safe filename sanitization
- Directory traversal protection

### File Permissions:
```bash
/mcp/audits/           - 755 (rwxr-xr-x)
/mcp/audits/files/     - 755 (rwxr-xr-x)
/mcp/audits/*.php      - 644 (rw-r--r--)
/mcp/audits/audits.db  - 644 (rw-r--r--)
```

---

## 🚀 Quick Start Commands

### Test Complete Audit:
```bash
cd /home/129337.cloudwaysapps.com/hdgwrzntwa/public_html/frontend-tools
node examples/comprehensive-audit.js https://staff.vapeshed.co.nz
```

### Test Individual Modules:
```bash
# Browser Controller
node core/browser-controller.js

# Error Detector
node core/error-detector.js

# Screenshot Tool
node core/screenshot-tool.js

# Reporter
node lib/reporter.js
```

### View Gallery:
```bash
# Open in browser:
https://gpt.ecigdis.co.nz/audits/gallery.php
```

---

## 📈 Usage Tracking

### View Audit History:
```javascript
const reporter = new Reporter();

// Get last 10 audits
const history = await reporter.getAuditHistory({ limit: 10 });
console.log(history.audits);

// Get audits since date
const recent = await reporter.getAuditHistory({
  since: '2025-11-01'
});

// Get by type
const screenshots = await reporter.getAuditHistory({
  type: 'screenshot'
});
```

### View Error History:
```javascript
// Get last 10 errors
const errors = await reporter.getErrorHistory({ limit: 10 });
console.log(errors.errors);

// Get errors since date
const recentErrors = await reporter.getErrorHistory({
  since: '2025-11-01'
});
```

---

## 🎨 Gallery Customization

### URL Parameters:
```
?project=cis-frontend               # Filter by project
?server=staff-portal                # Filter by server
?audit=audit_123_abc                # View specific audit
?type=image                         # Filter screenshots
?type=video                         # Filter videos
?since=2025-11-01                   # Filter by date
?page=2                             # Pagination
```

### Example URLs:
```
# All CIS frontend audits
https://gpt.ecigdis.co.nz/audits/gallery.php?project=cis-frontend

# Staff portal screenshots only
https://gpt.ecigdis.co.nz/audits/gallery.php?project=cis-frontend&server=staff-portal&type=image

# Audits from today
https://gpt.ecigdis.co.nz/audits/gallery.php?since=2025-11-04

# Specific audit
https://gpt.ecigdis.co.nz/audits/gallery.php?audit=audit_123_abc
```

---

## ✅ System Status

### Completed:
✅ Reporter module with upload capability
✅ Upload handler on GPT server
✅ Gallery viewer with filtering
✅ SQLite database for metadata
✅ Direct link generation
✅ Gallery link generation
✅ Audit logging
✅ Error logging
✅ Project/server organization
✅ Bot response formatting
✅ Comprehensive audit example

### Features:
✅ Direct image links (for quick viewing)
✅ Gallery links (for history browsing)
✅ Web-based gallery viewer
✅ Search and filter
✅ Error tracking
✅ Audit history
✅ Thumbnail previews
✅ Video playback support
✅ Pagination (50 per page)
✅ Download capability
✅ Metadata display

---

## 🔧 Configuration

### Frontend Tools Config:
```javascript
{
  projectId: 'cis-frontend',        // Your project identifier
  serverId: 'staff-portal',         // Server/environment identifier
  uploadUrl: 'https://gpt.ecigdis.co.nz/audits/upload.php',
  galleryUrl: 'https://gpt.ecigdis.co.nz/audits/gallery.php',
  apiKey: '31ce0106609a6c5bc4f7ece0deb2f764df90a06167bda83468883516302a6a35',
  localStoragePath: '/tmp/frontend-audits',
  maxRetries: 3,
  timeout: 30000
}
```

### GPT Server Config:
```php
define('UPLOAD_BASE_DIR', __DIR__ . '/files');
define('DATABASE_FILE', __DIR__ . '/audits.db');
define('VALID_API_KEY', '31ce0106609a6c5bc4f7ece0deb2f764df90a06167bda83468883516302a6a35');
define('MAX_FILE_SIZE', 100 * 1024 * 1024); // 100MB
```

---

## 🎯 Next Steps

1. ✅ Test upload with real screenshot
2. ✅ Verify gallery displays correctly
3. ✅ Check direct links work
4. ✅ Test filtering/search
5. ✅ Verify error logging
6. ✅ Test audit history retrieval

---

## 📞 Support

**Files:**
- `lib/reporter.js` - Reporter module
- `mcp/audits/upload.php` - Upload handler
- `mcp/audits/gallery.php` - Gallery viewer
- `examples/comprehensive-audit.js` - Complete example

**Documentation:**
- This file: `AUDIT_GALLERY_SYSTEM.md`
- Bot usage: `BOT_USAGE_GUIDE.md`
- Frontend tools: `FRONTEND_TOOLS_BREAKDOWN.md`

---

**Version:** 1.0.0
**Last Updated:** November 4, 2025
**Status:** ✅ Production Ready
