# Bots Guide: Complete Tool Ecosystem & Preload Instructions

Last updated: 2025-11-04

This workspace is configured for **advanced AI-assisted development** with 100+ tools. Below are all tool surfaces, preload instructions, and usage guidelines.

---

## 🚀 PRELOAD INSTRUCTIONS FOR BOTS

**CRITICAL:** All AI assistants MUST preload these documents on session start:

### Phase 1: Core System Knowledge (LOAD FIRST)

```javascript
const coreDocuments = [
  '/MASTER_SYSTEM_GUIDE.md',                              // Complete system reference
  '/COMPLETE_TOOLS_QUICK_REFERENCE.md',                   // All 100+ tools indexed
  '/.vscode/bot-preload-config.json',                     // Bot configuration
  '/PRODUCTION_READY.md',                                 // Production status
  '/README.md'                                            // System overview
];
```

### Phase 2: Frontend Automation (LOAD SECOND)

```javascript
const frontendDocs = [
  '/FRONTEND_TOOLS_BREAKDOWN.md',                         // 43+ testing tools
  '/frontend-tools/INTEGRATION_MASTER_PLAN.md',          // AI Agent integration architecture
  '/frontend-tools/AUTOMATION_ROADMAP.md',               // 15 automation features
  '/frontend-tools/ARCHITECTURE_DEEP_DIVE.md',           // 12,000+ word technical guide
  '/frontend-tools/AUDIT_GALLERY_SYSTEM.md',             // Gallery system docs
  '/ai-agent/FRONTEND_INTEGRATION_SETUP.md'              // Complete setup guide
];
```

### Phase 3: Database & APIs (LOAD THIRD)

```javascript
const databaseDocs = [
  '/ai-agent/migrations/frontend_integration_schema.sql', // Database schema (9 tables)
  '/ai-agent/src/Tools/Frontend/FrontendToolRegistry.php', // Tool registry (7 tools)
  '/ai-agent/api/execute-workflow.php',                  // Workflow execution
  '/ai-agent/api/approve-fix.php'                        // Fix approval system
];
```

### Complete Preload Function:

```javascript
async function preloadAllDocs() {
  const allDocs = [...coreDocuments, ...frontendDocs, ...databaseDocs];

  console.log('🤖 Bot Initialization Starting...');
  console.log(`📚 Loading ${allDocs.length} documents...`);

  for (const doc of allDocs) {
    try {
      const content = await readFile(doc);
      await indexDocument(doc, content);
      console.log(`  ✅ Loaded: ${doc}`);
    } catch (error) {
      console.log(`  ⚠️  Skipped: ${doc} (${error.message})`);
    }
  }

  console.log('✅ Bot initialization complete!');
  console.log('🧠 Context loaded: Full system knowledge available');
}

// Auto-execute on bot startup
preloadAllDocs();
```

### Why Preload?

- ✅ **Instant Context:** Bot knows full system (100+ tools) immediately
- ✅ **Better Responses:** Can reference any tool without searching
- ✅ **Consistency:** All bots have identical baseline knowledge
- ✅ **Speed:** No discovery phase during conversation
- ✅ **Completeness:** Knows about frontend automation, workflows, approvals
- ✅ **Database Aware:** Understands all 9 new tables and their purpose

---

## 📦 COMPLETE TOOL INVENTORY

### 1️⃣ MCP Intelligence Hub (13 Core Search/Analysis Tools)

**Endpoint:** `https://gpt.ecigdis.co.nz/mcp/server_v2_complete.php`

**Available Tools:**

1. **semantic_search** — Natural language search across 22,185 files
   ```json
   { "query": "how to handle inventory", "limit": 10 }
   ```

2. **search_by_category** — Search within 31 business categories
   ```json
   { "query": "stock transfer", "category_name": "Inventory Management", "limit": 20 }
   ```

3. **find_code** — Locate functions, classes, patterns
   ```json
   { "pattern": "calculateTotal", "search_in": "all", "limit": 20 }
   ```

4. **find_similar** — Find files similar to reference file
   ```json
   { "file_path": "modules/inventory/count.php", "limit": 10 }
   ```

5. **explore_by_tags** — Search by semantic tags
   ```json
   { "semantic_tags": ["validation", "security"], "match_all": false, "limit": 20 }
   ```

6. **analyze_file** — Deep file analysis with metrics
   ```json
   { "file_path": "modules/transfers/pack.php" }
   ```

7. **get_file_content** — File content with surrounding context
   ```json
   { "file_path": "api/save_transfer.php", "include_related": true }
   ```

8. **health_check** — System health and statistics
   ```json
   {}
   ```

9. **get_stats** — System-wide statistics
   ```json
   { "breakdown_by": "unit" }
   ```

10. **top_keywords** — Most common keywords
    ```json
    { "unit_id": 2, "limit": 50 }
    ```

11. **list_categories** — Show all 31 business categories
    ```json
    { "min_priority": 1.3, "order_by": "priority" }
    ```

12. **get_analytics** — Real-time analytics data
    ```json
    { "action": "overview", "timeframe": "24h" }
    ```

13. **Satellite Tools:** `list_satellites`, `sync_satellite`

**How to Call (JSON-RPC):**
```json
{
  "jsonrpc": "2.0",
  "method": "tools/call",
  "params": {
    "name": "semantic_search",
    "arguments": { "query": "...", "limit": 10 }
  },
  "id": 1
}
```

**Auth:** Bearer token (set `INTELLIGENCE_HUB_API_KEY` environment variable)

---

### 2️⃣ Frontend Automation Tools (7 Tools via ToolChainOrchestrator)

**Registered in:** `/ai-agent/src/Tools/Frontend/FrontendToolRegistry.php`

**Available Tools:**

1. **frontend_audit_page** — Comprehensive page audit
   ```php
   [
     'url' => 'https://staff.vapeshed.co.nz',
     'checks' => ['errors', 'performance', 'accessibility'],
     'auto_fix' => false,
     'approval_required' => true
   ]
   ```

2. **frontend_screenshot** — Capture screenshots
   ```php
   [
     'url' => 'https://staff.vapeshed.co.nz',
     'type' => 'full_page',
     'device' => 'desktop',
     'upload' => true
   ]
   ```

3. **frontend_monitor_start** — Start continuous monitoring
   ```php
   [
     'url' => 'https://staff.vapeshed.co.nz',
     'interval' => '5m',
     'checks' => ['errors', 'performance'],
     'alert_channels' => ['email']
   ]
   ```

4. **frontend_auto_fix** — AI-powered auto-fix (with approval)
   ```php
   [
     'fix_id' => 123,
     'approval_required' => true,
     'run_tests' => true
   ]
   ```

5. **frontend_visual_regression** — Screenshot comparison
   ```php
   [
     'url' => 'https://staff.vapeshed.co.nz',
     'baseline' => 'path/to/baseline.png',
     'threshold' => 0.10
   ]
   ```

6. **frontend_performance_audit** — Lighthouse integration
   ```php
   [
     'url' => 'https://staff.vapeshed.co.nz',
     'categories' => ['performance', 'accessibility', 'seo']
   ]
   ```

7. **frontend_accessibility_check** — WCAG compliance
   ```php
   [
     'url' => 'https://staff.vapeshed.co.nz',
     'level' => 'AA',
     'report_format' => 'json'
   ]
   ```

**How to Execute:**
```php
// Via workflow API
POST /ai-agent/api/execute-workflow.php
{
  "nodes": [
    {
      "id": "node1",
      "type": "audit",
      "config": {
        "url": "https://staff.vapeshed.co.nz",
        "checks": ["errors", "performance"],
        "auto_fix": false
      }
    }
  ],
  "connections": []
}
```

---

### 3️⃣ Frontend Testing Scripts (43+ Tools)

**Location:** `/home/129337.cloudwaysapps.com/hdgwrzntwa/public_html/frontend-tools/`

**Core Testing Tools:**

1. **comprehensive-audit.js** — Complete page analysis
   ```bash
   node examples/comprehensive-audit.js https://staff.vapeshed.co.nz
   ```

2. **test-screenshot.js** — Screenshot capture
   ```bash
   node examples/test-screenshot.js https://staff.vapeshed.co.nz full_page desktop
   ```

3. **test-browser.js** — Browser automation (600 lines)
4. **test-profile.js** — Profile management (450 lines, AES-256-GCM)
5. **test-error-detector.js** — Error detection (376 lines)
6. **reporter.js** — Gallery uploader (650 lines)

**Plus 37+ more tools** — See FRONTEND_TOOLS_BREAKDOWN.md for complete list

---

### 4️⃣ Local MCP v3 Tools (Intelligence Hub Agent)

**Endpoint:** `https://gpt.ecigdis.co.nz/assets/services/ai-agent/mcp/server_v3.php`

**Integrated Tools:**
- PasswordStorageTool — secure storage and retrieval of credentials (scoped)
- MySQLQueryTool — parameterized DB queries (read/write with safeguards)
- WebBrowserTool — HTTP fetch/crawl with headers, status, body (safe modes)
- CrawlerTool — higher-level crawling routines (audit/test/crawl split planned)

How to call (JSON-RPC):
- method: tools/call
- params: { name: "web_browser.fetch", arguments: { url: "https://...", method: "GET" } }

Note: Exact method names may be namespaced by the invoker; see server_v3 catalog (tools/list) at runtime.

## 3) AI Agent Tools (Project-local)
Location: `public_html/ai-agent/src/Tools/`

Active tools:
- KnowledgeTool — semantic KB access
- MemoryTool — conversation history/context
- FileTool — sandboxed file access
- OpsTools — readiness checks and repo cleanup helpers
- DeputyHRTool — Deputy HR integration (internal)

Disabled/Restricted:
- CodeTool.php.DISABLED — code execution helpers (disabled for security)

The AI Agent orchestrator (`src/Agent.php`) and registry (`src/Tools/ToolRegistry.php`) manage availability. Some tools write to telemetry tables (e.g., ai_agent_requests).

## 4) Editor & Frontend Dev Setup
- Location: `public_html/.vscode/settings.json`
- Copilot enabled; inline suggestions on; Copilot Chat codegen on.
- MCP wired:
  - Root MCP (intelligence-hub) for the local agent
  - Copilot advanced MCP server (cis-kb) for KB queries
- PHP: Intelephense (default formatter), php-cs-fixer (PSR‑12) on save
- JS/TS: Prettier + ESLint with fixAll on save
- Search excludes: logs/, sessions/, cache/, node_modules/, .git

Extensions (recommended):
- Copilot, Copilot Chat, Intelephense, PHP CS Fixer, Prettier, ESLint, Spell Checker, TODO Tree, Git Graph, Docker

## 5) Environment & Secrets
- Do not commit secrets. Keep `.env` files outside public web roots where possible (e.g., `private_html/config/`).
- Known sensitive file to keep private: `public_html/ai-agent/.env` (rotate and relocate if committed historically).

## 6) Quick Reference
- Tool catalogs:
  - Hub (v2 complete): tools/list → 13+ tools
  - Local v3: `server_v3.php` tools/list → password/mysql/browser/crawler
- Health:
  - Hub: health_check tool
  - AI Agent: `https://staff.vapeshed.co.nz/ai-agent/api/health.php` (if present)
- Logging: AI calls and messages recorded in ai_agent_* tables when using the local agent API

If a bot needs a tool not listed here, query the MCP server’s tools/list first, then call with tools/call. For domain-specific testing (Vend/Lightspeed, webhook lab), upcoming endpoints will be added under `?endpoint=admin/...` per the dashboard plan.
