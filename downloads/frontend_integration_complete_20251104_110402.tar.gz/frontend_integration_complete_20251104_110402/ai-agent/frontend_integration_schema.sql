-- ============================================================
-- Frontend Integration Database Schema
-- Purpose: Store approvals, workflows, and automation history
-- Date: November 4, 2025
-- ============================================================

-- Table: frontend_pending_fixes
-- Stores AI-generated fixes awaiting user approval
CREATE TABLE IF NOT EXISTS frontend_pending_fixes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    url VARCHAR(500) NOT NULL,
    file_path VARCHAR(500),
    line_number INT,
    fix_type VARCHAR(50) DEFAULT 'auto',
    original_code TEXT,
    fixed_code TEXT,
    reason TEXT,
    screenshot_path VARCHAR(500),
    errors_json JSON,
    status ENUM('pending', 'approved', 'rejected', 'applied', 'failed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    reviewed_at TIMESTAMP NULL,
    reviewed_by VARCHAR(100),
    applied_at TIMESTAMP NULL,
    notes TEXT,
    INDEX idx_status (status),
    INDEX idx_created (created_at),
    INDEX idx_url (url(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: frontend_workflows
-- Stores saved workflows for reuse
CREATE TABLE IF NOT EXISTS frontend_workflows (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    workflow_json JSON NOT NULL,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_executed TIMESTAMP NULL,
    execution_count INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    tags JSON,
    INDEX idx_name (name),
    INDEX idx_active (is_active),
    INDEX idx_created_by (created_by)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: frontend_workflow_executions
-- Stores workflow execution history
CREATE TABLE IF NOT EXISTS frontend_workflow_executions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    workflow_id INT,
    execution_id VARCHAR(100) UNIQUE,
    status ENUM('running', 'completed', 'failed', 'cancelled') DEFAULT 'running',
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    duration_ms INT,
    steps_total INT,
    steps_completed INT,
    steps_failed INT,
    result_json JSON,
    error_message TEXT,
    triggered_by VARCHAR(100),
    INDEX idx_workflow (workflow_id),
    INDEX idx_status (status),
    INDEX idx_started (started_at),
    FOREIGN KEY (workflow_id) REFERENCES frontend_workflows(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: frontend_audit_history
-- Stores page audit results
CREATE TABLE IF NOT EXISTS frontend_audit_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    audit_id VARCHAR(100) UNIQUE,
    url VARCHAR(500) NOT NULL,
    audit_type VARCHAR(50) DEFAULT 'comprehensive',
    errors_total INT DEFAULT 0,
    errors_json JSON,
    performance_json JSON,
    accessibility_json JSON,
    seo_json JSON,
    screenshot_path VARCHAR(500),
    gallery_url VARCHAR(500),
    duration_ms INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_url (url(255)),
    INDEX idx_created (created_at),
    INDEX idx_audit_id (audit_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: frontend_monitors
-- Stores active monitoring configurations
CREATE TABLE IF NOT EXISTS frontend_monitors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    url VARCHAR(500) NOT NULL,
    check_interval VARCHAR(20) DEFAULT '5m',
    check_types JSON,
    alert_channels JSON,
    last_check TIMESTAMP NULL,
    last_status VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT,
    INDEX idx_active (is_active),
    INDEX idx_url (url(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: frontend_monitor_alerts
-- Stores monitoring alerts
CREATE TABLE IF NOT EXISTS frontend_monitor_alerts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    monitor_id INT,
    alert_type VARCHAR(50),
    severity ENUM('info', 'warning', 'error', 'critical') DEFAULT 'warning',
    message TEXT,
    details_json JSON,
    triggered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL,
    notified_at TIMESTAMP NULL,
    status ENUM('new', 'notified', 'acknowledged', 'resolved') DEFAULT 'new',
    INDEX idx_monitor (monitor_id),
    INDEX idx_status (status),
    INDEX idx_triggered (triggered_at),
    FOREIGN KEY (monitor_id) REFERENCES frontend_monitors(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: frontend_screenshot_gallery
-- Extended screenshot metadata
CREATE TABLE IF NOT EXISTS frontend_screenshot_gallery (
    id INT AUTO_INCREMENT PRIMARY KEY,
    screenshot_id VARCHAR(100) UNIQUE,
    url VARCHAR(500) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_size INT,
    width INT,
    height INT,
    type VARCHAR(50) DEFAULT 'full_page',
    device VARCHAR(50),
    audit_id VARCHAR(100),
    tags JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_url (url(255)),
    INDEX idx_audit (audit_id),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: frontend_visual_regression
-- Visual regression test results
CREATE TABLE IF NOT EXISTS frontend_visual_regression (
    id INT AUTO_INCREMENT PRIMARY KEY,
    test_id VARCHAR(100) UNIQUE,
    url VARCHAR(500) NOT NULL,
    baseline_screenshot VARCHAR(500),
    current_screenshot VARCHAR(500),
    diff_screenshot VARCHAR(500),
    diff_percentage DECIMAL(5,2),
    threshold DECIMAL(5,2) DEFAULT 0.10,
    status ENUM('pass', 'fail', 'baseline') DEFAULT 'pass',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_url (url(255)),
    INDEX idx_status (status),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: frontend_deployment_log
-- Track all code changes/deployments
CREATE TABLE IF NOT EXISTS frontend_deployment_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    deployment_id VARCHAR(100) UNIQUE,
    fix_id INT,
    file_path VARCHAR(500),
    action ENUM('create', 'update', 'delete') DEFAULT 'update',
    backup_path VARCHAR(500),
    changes_json JSON,
    deployed_by VARCHAR(100),
    deployed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    rollback_available BOOLEAN DEFAULT TRUE,
    rolled_back_at TIMESTAMP NULL,
    INDEX idx_fix (fix_id),
    INDEX idx_file (file_path(255)),
    INDEX idx_deployed (deployed_at),
    FOREIGN KEY (fix_id) REFERENCES frontend_pending_fixes(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Insert sample data for testing
-- ============================================================

-- Sample workflow: "Quick Page Audit"
INSERT INTO frontend_workflows (name, description, workflow_json, tags) VALUES (
    'Quick Page Audit',
    'Fast audit of any page - checks errors and performance',
    JSON_OBJECT(
        'nodes', JSON_ARRAY(
            JSON_OBJECT(
                'id', 'node_1',
                'type', 'audit',
                'x', 100,
                'y', 100,
                'config', JSON_OBJECT(
                    'url', 'https://staff.vapeshed.co.nz',
                    'checks', JSON_ARRAY('errors', 'performance'),
                    'auto_fix', false
                )
            ),
            JSON_OBJECT(
                'id', 'node_2',
                'type', 'screenshot',
                'x', 350,
                'y', 100,
                'config', JSON_OBJECT(
                    'type', 'full_page',
                    'upload', true
                )
            )
        ),
        'connections', JSON_ARRAY(
            JSON_OBJECT('from', 'node_1', 'to', 'node_2')
        )
    ),
    JSON_ARRAY('quick', 'audit', 'testing')
);

-- Sample workflow: "Auto-Fix Pipeline"
INSERT INTO frontend_workflows (name, description, workflow_json, tags) VALUES (
    'Auto-Fix Pipeline',
    'Complete pipeline: audit → detect errors → auto-fix → test',
    JSON_OBJECT(
        'nodes', JSON_ARRAY(
            JSON_OBJECT(
                'id', 'node_1',
                'type', 'audit',
                'x', 100,
                'y', 150,
                'config', JSON_OBJECT(
                    'url', 'https://staff.vapeshed.co.nz',
                    'checks', JSON_ARRAY('errors'),
                    'auto_fix', false
                )
            ),
            JSON_OBJECT(
                'id', 'node_2',
                'type', 'condition',
                'x', 350,
                'y', 150,
                'config', JSON_OBJECT(
                    'field', 'errors.total',
                    'operator', '>',
                    'value', 0
                )
            ),
            JSON_OBJECT(
                'id', 'node_3',
                'type', 'fix',
                'x', 600,
                'y', 100,
                'config', JSON_OBJECT(
                    'approval_required', true,
                    'run_tests', true
                )
            ),
            JSON_OBJECT(
                'id', 'node_4',
                'type', 'screenshot',
                'x', 850,
                'y', 100,
                'config', JSON_OBJECT(
                    'type', 'full_page',
                    'upload', true
                )
            )
        ),
        'connections', JSON_ARRAY(
            JSON_OBJECT('from', 'node_1', 'to', 'node_2'),
            JSON_OBJECT('from', 'node_2', 'to', 'node_3', 'condition', 'true'),
            JSON_OBJECT('from', 'node_3', 'to', 'node_4')
        )
    ),
    JSON_ARRAY('auto-fix', 'pipeline', 'production')
);

-- Sample workflow: "24/7 Monitoring"
INSERT INTO frontend_workflows (name, description, workflow_json, tags) VALUES (
    '24/7 Monitoring',
    'Continuous monitoring with alerts',
    JSON_OBJECT(
        'nodes', JSON_ARRAY(
            JSON_OBJECT(
                'id', 'node_1',
                'type', 'monitor',
                'x', 100,
                'y', 100,
                'config', JSON_OBJECT(
                    'interval', '5m',
                    'checks', JSON_ARRAY('errors', 'performance', 'uptime'),
                    'alert_channels', JSON_ARRAY('email', 'slack')
                )
            )
        ),
        'connections', JSON_ARRAY()
    ),
    JSON_ARRAY('monitoring', 'alerts', 'production')
);

-- ============================================================
-- Create indexes for performance
-- ============================================================

-- Composite indexes for common queries
CREATE INDEX idx_pending_fixes_status_created ON frontend_pending_fixes(status, created_at DESC);
CREATE INDEX idx_audit_url_created ON frontend_audit_history(url(255), created_at DESC);
CREATE INDEX idx_executions_workflow_status ON frontend_workflow_executions(workflow_id, status, started_at DESC);

-- ============================================================
-- Grant permissions (adjust user as needed)
-- ============================================================

-- GRANT SELECT, INSERT, UPDATE, DELETE ON frontend_* TO 'ai_agent_user'@'localhost';

-- ============================================================
-- Success message
-- ============================================================

SELECT 'Frontend Integration Schema Created Successfully!' as status,
       (SELECT COUNT(*) FROM frontend_workflows) as sample_workflows_created;
