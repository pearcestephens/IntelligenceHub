#!/bin/bash
# Quick Installation Script
# Run from deployment package root

set -e

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║     Frontend Integration - Quick Install                      ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

# Check if running as root
if [[ $EUID -eq 0 ]]; then
   echo "❌ Don't run as root. Run as your web user."
   exit 1
fi

echo "📍 Current directory: $(pwd)"
echo ""

# Prompt for installation path
read -p "Enter AI-Agent installation path [/home/129337.cloudwaysapps.com/hdgwrzntwa/public_html/ai-agent]: " AI_AGENT_PATH
AI_AGENT_PATH=${AI_AGENT_PATH:-/home/129337.cloudwaysapps.com/hdgwrzntwa/public_html/ai-agent}

read -p "Enter database name [hdgwrzntwa]: " DB_NAME
DB_NAME=${DB_NAME:-hdgwrzntwa}

read -p "Enter database user [hdgwrzntwa]: " DB_USER
DB_USER=${DB_USER:-hdgwrzntwa}

read -s -p "Enter database password: " DB_PASS
echo ""

echo ""
echo "🚀 Starting installation..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# 1. Install database schema
echo "📊 Installing database schema..."
mysql -u "$DB_USER" -p"$DB_PASS" "$DB_NAME" < ai-agent/frontend_integration_schema.sql
echo "✅ Database schema installed"

# 2. Copy AI-Agent files
echo "📁 Copying AI-Agent files..."
mkdir -p "${AI_AGENT_PATH}/src/Tools/Frontend"
mkdir -p "${AI_AGENT_PATH}/public/dashboard/assets/js"
mkdir -p "${AI_AGENT_PATH}/api"

cp -v ai-agent/FrontendToolRegistry.php "${AI_AGENT_PATH}/src/Tools/Frontend/" 2>/dev/null || echo "Skip FrontendToolRegistry.php"
cp -v ai-agent/approvals.php "${AI_AGENT_PATH}/public/dashboard/" 2>/dev/null || echo "Skip approvals.php"
cp -v ai-agent/api/*.php "${AI_AGENT_PATH}/api/" 2>/dev/null || echo "Skip APIs"
cp -v ai-agent/dashboard/assets/js/*.js "${AI_AGENT_PATH}/public/dashboard/assets/js/" 2>/dev/null || echo "Skip JS"

echo "✅ AI-Agent files copied"

# 3. Set permissions
echo "🔐 Setting permissions..."
chmod -R 755 "${AI_AGENT_PATH}"
chmod 644 "${AI_AGENT_PATH}"/**/*.php 2>/dev/null || true
chmod 644 "${AI_AGENT_PATH}"/**/*.js 2>/dev/null || true

echo "✅ Permissions set"

# 4. Done
echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║                  ✅ INSTALLATION COMPLETE!                     ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""
echo "Next steps:"
echo "1. Visit: https://your-domain.com/ai-agent/public/dashboard/approvals.php"
echo "2. Visit: https://your-domain.com/ai-agent/public/dashboard/workflows.php"
echo "3. Read: ai-agent/FRONTEND_INTEGRATION_SETUP.md"
echo ""
echo "🎉 Enjoy your new frontend automation system!"
