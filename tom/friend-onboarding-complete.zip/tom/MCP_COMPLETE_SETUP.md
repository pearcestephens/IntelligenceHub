# MCP Intelligence Hub - Complete Setup Guide

## 🔑 All Authentication Keys & Details

### MCP API Key
```
MCP_API_KEY=31ce0106609a6c5bc4f7ece0deb2f764df90a06167bda83468883516302a6a35
```

### Database Credentials
```
DB_HOST=localhost
DB_NAME=hdgwrzntwa
DB_USER=hdgwrzntwa
DB_PASS=bFUdRjh4Jx
```

### SSH Access
```
Host: master_anjzctzjhr@hdgwrzntwa
Full Path: master_anjzctzjhr@138.201.124.48
Port: 22 (default)
```

### MCP Server Details
```
URL: https://gpt.ecigdis.co.nz/mcp/server_v3.php
Path: /home/129337.cloudwaysapps.com/hdgwrzntwa/public_html/mcp
Wrapper: mcp-server-wrapper.js
```

## 📦 Complete File List

This package includes:

### Friend Onboarding (7 files)
- FRIEND_ONBOARDING_INSTALLER.sh
- FRIEND_ONBOARDING_README.md
- FRIEND_ONBOARDING_READY_TO_USE.md
- FRIEND_PACKAGE_SYSTEM_COMPLETE.md
- FRIEND_QUICK_REFERENCE.md
- FRIEND_USER_TUTORIAL.md
- CREATE_FRIEND_PACKAGE.sh

### MCP Server Files (2 files)
- server_v3.php (main MCP server)
- mcp-server-wrapper.js (Node.js STDIO wrapper)

### MCP Configuration (6 files)
- .env (all keys and credentials)
- mcp.json (VS Code MCP config)
- settings.json (MCP-specific settings)
- mcp-config.json (additional MCP config)
- database.php (DB connection config)
- vscode-mcp-settings.json (VS Code integration)

### Documentation (5 files)
- README.md (package overview)
- ONBOARDING_COMPLETE_SUMMARY.md
- ONBOARDING_PACKAGE_FOR_FRIENDS.md
- COPILOT_INSTRUCTIONS_MASTER_BACKUP.md
- MCP_COMPLETE_SETUP.md (this file)

## 🚀 Quick Setup

1. **Extract Package**
   ```bash
   unzip friend-onboarding-complete.zip
   cd tom/
   ```

2. **Run Installer**
   ```bash
   chmod +x FRIEND_ONBOARDING_INSTALLER.sh
   ./FRIEND_ONBOARDING_INSTALLER.sh
   ```

3. **Configure SSH**
   - Generate SSH key: `ssh-keygen -t ed25519 -C "your@email.com"`
   - Send public key to admin for authorized_keys
   - Test: `ssh master_anjzctzjhr@138.201.124.48`

4. **Reload VS Code**
   - Open VS Code
   - MCP will auto-connect
   - Sandbox PROJECT_ID=999 active

## 🔒 Security Notes

- All keys are REAL production keys
- Sandbox isolation via PROJECT_ID=999
- Full tool access, isolated data
- SSH key required (no password auth)

## ✅ Verification

After setup:
1. VS Code should show MCP connected
2. Can use conversation memory tools
3. Can search 8,645+ indexed files
4. Sandbox environment active

## 📞 Support

Any issues: pearce.stephens@ecigdis.co.nz

**Everything you need is in this package!** 🎉
